PETER BEYER ARCHITECT — RESTORED HTML WEBSITE

Open index.html in a web browser. No installation or build is needed.
Keep all HTML files, site.css, site.js and the assets folder together.
To upload to ordinary static web hosting, upload this folder's contents.

Restored from 14 saved Jimdo pages supplied by Peter Beyer.
Original content, project captions, guestbook entries and images are retained.
The original grey navigation and orange header are retained, with responsive
layouts for mobile and click-to-enlarge images (Escape closes the viewer).

Contact forms download a text enquiry to the visitor's device. They DO NOT
send email. The site also offers click-to-call contact on 0411 323 296.
There is no email address or working mail service in the supplied source.
Guestbook submissions direct visitors to contact Peter; no public posting
service is connected. Existing saved entries are preserved.

The original Links page was not supplied. links.html provides an explicit
notice and directory. Original links to other unsaved Jimdo pages are shown
as text with a tooltip. Videos link to their original YouTube watch page
and require internet access; playback availability has not been verified.
External links and historical content are preserved as supplied and were
not independently fact-checked or updated. No Jimdo admin or tracking scripts
are included. No website has been published or existing domain changed.

Verification: local asset and page links checked; JavaScript syntax checked.
Visual browser QA could not be completed because the preview tool timed out.
restoration-report.json lists source pages and the asset restoration count.
